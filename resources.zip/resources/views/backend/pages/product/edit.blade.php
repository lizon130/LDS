<form id="editProductForm" action="{{ route('admin.product.update', $product->id)}}" method="post" enctype="multipart/form-data">
    @csrf 
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Product</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true"><i class="fa-solid fa-xmark"></i></span>
        </button>
    </div>
    <div class="modal-body row">
        <div class="row">
            <div class="col-sm-12">
                <div class="server_side_error" role="alert">

                </div>
            </div>
            <div class="col-sm-12 tab-content" id="v-pills-tabContent">
                <div class="step step_1 tab-pane fade show active" id="v-pills-edithome" role="tabpanel" aria-labelledby="v-pills-edithome-tab">
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label for="">Product Name<span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" placeholder="Product Name" value="{{ $product->getTranslation(Session::get('admin_language') ?? 'en', 'name') ?? '' }}" required>
                        </div>
                        <div class="col-lg-6">
                            <label for="">Product Code<span class="text-danger">*</span></label>
                            <input type="text" name="code" class="form-control" placeholder="Product code" value="{{ $product->code }}"  required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label>Category<span class="text-danger">*</span></label>
                            <select name="category" class="form-control main_category" required>
                                <option value="">Select</option>
                                @foreach ($category as $cat)
                                    <option @if($product->category_id == $cat->id) selected @endif value="{{ $cat->id}}">{{ $cat->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label>Brand</label>
                            <select name="brand" class="form-control">
                                <option value="">Select</option>
                                @foreach ($brands as $brand)
                                    <option @if($product->brand_id == $brand->id) selected @endif value="{{ $brand->id}}">{{ $brand->title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label>Sub-Category</label>
                            <select name="sub_category_id" class="form-control edit_category_select2" style="width: 100%;" required>
                                <option value="">Select</option>
                                @foreach ($sub_category as $cat)
                                    <option @if($product->sub_category_id == $cat->id) selected @endif value="{{ $cat->id}}">{{ $cat->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="">Price</label>
                            <input type="text" name="price" class="form-control" placeholder="Product price" value="{{ $product->price }}"  >
                        </div>

                        <div class="col-lg-3">
                            <label for="status" class="mt-1">Visibility</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" @if($product->status == 1) checked @endif name="status" id="status">
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <label for="features" class="mt-1">Show On Home</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" @if($product->features == 1) checked @endif name="features" id="features">
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <label for="show_price" class="form-label mt-1">Show Price To Customers</label>
                            <div class="d-flex align-items-center">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" @if($product->show_price == 1) checked @endif name="show_price" id="show_price">
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3">
                            <label for="show_price_to_partner" class="form-label mt-1">Show Price To  Partner</label>
                            <div class="d-flex align-items-center">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" @if($product->show_price_to_partner == 1) checked @endif name="show_price_to_partner" id="show_price_to_partner">
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="step step_2 tab-pane fade">
                    
                    <div class="form-group">
                        <label for="">Key Features</label>
                        <textarea class="tinymceText form-control" id="key_features" rows="5">{!! $product->getTranslation(Session::get('admin_language') ?? 'en', 'key_features') ?? '' !!}</textarea>
                    </div>
                </div>
                <div class="step step_3 tab-pane fade">
                    <div class="form-group">
                        <label for="">Further Information</label>
                        <textarea class="tinymceText form-control" id="further_information" rows="5">{!! $product->getTranslation(Session::get('admin_language') ?? 'en', 'further_information') ?? '' !!}</textarea>
                    </div>
                </div>
                <div class="step step_4 tab-pane fade" >
                    <p>SEO Information</p>
                    <hr>
                    <div class="form-group">
                        <label for="">Meta Title</label>
                        <input type="text" name="meta_title" value="{{ $product->meta_title }}" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Meta Tag</label>
                        <select class="form-control" name="meta_tag[]" id="meta_tag" multiple="multiple">
                            @foreach (explode(',', $product->meta_tags) as $key => $tag)
                                <option selected value="{{ $tag }}">{{ $tag }}</option>
                            @endforeach
                            <option value="Machine Tools Solution">Machine Tools Solution</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Meta Description</label>
                        <textarea class="tinymceText form-control" id="meta_descriptions" rows="5">{!! $product->meta_descriptions !!}</textarea>
                    </div>
                </div>
                <div class="step step_5 tab-pane fade" >
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <label for="">Discount Type</label>
                            <select name="discount_type" id="" class="form-control">
                                <option value="">Discount Type</option>
                                <option @if($product->discount_type == 'percent') selected @endif value="percent">Percent</option>
                                <option @if($product->discount_type == 'amount') selected @endif value="amount">Amount</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label for="">Discount</label>
                            <input type="text" name="discount" class="form-control" placeholder="Product discount" value="{{ $product->discount }}" >
                        </div>
                    </div>

                    <div class="form-group attributes_area">
                        <table class="w-100">
                            <thead>
                                <tr>
                                    <th class="w-5">Filter</th>
                                    <th class="w-50">Attributes Name</th>
                                    <th class="w-40">Attributes Value</th>
                                    <th class="w-5 text-center"><a href="" type="button" id="addAttributes" class="btn btn-sm btn-primary"><i class="fa-solid fa-plus"></i></a></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($product->attributes as $row)
                                    <tr class="attributes{{$loop->iteration}}">
                                        <td><input type="checkbox" class="attributes_filterable" name="filterable[]" value="1" @if($row->is_filter == 1) checked @endif></td>
                                        <td><input type="text" class="form-control" name="attributes_name[]" value="{{$row->attribute_name}}" placeholder="Attributes name"></td>
                                        <td><input type="text" class="form-control" name="attributes_value[]" value="{{$row->value}}" placeholder="Attributes value"></td>
                                        <td class="text-center"><a href="" type="button" data-row="{{$loop->iteration}}" class="btn btn-sm btn-danger remove_attributes" id="attributes{{$loop->iteration}}"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
                <div class="step step_6 tab-pane fade">
                    <div class="form-group">
                        <label >Thumbnail Image<span class="text-danger">*</span></label>
                        <input type="file" class="form-control" onchange="previewFile('editModal #thumbnail', 'editModal .preview_image')" name="thumbnail" id="thumbnail" required>

                        <img src="{{ ($product->thumbnail) ? asset('uploads/product-images/'.$product->thumbnail) :  asset('assets/img/no-img.jpg')}}" height="80px" width="100px" class="preview_image mt-1 border" alt="">
                        
                    </div>
                    <div class="form-group">
                        <label >Gallery Image</label>
                        <input type="file" multiple class="form-control" onchange="previewFile('editModal #gallery', 'editModal .gallery_preview_image')" name="gallery[]" id="gallery">

                        
						<div class="d-flex flex-wrap">
							<div class="position-relative ">
								<img src="{{asset('assets/img/no-img.jpg')}}" height="80px" width="100px" class="gallery_preview_image mt-1 border" alt="">
							</div>
							@php
								$images = json_decode($product->images) ?? [];
							@endphp
							@if(count($images) > 0)
								@foreach($images as $key => $val)
									<div class="position-relative ms-1">
										<img src="{{ asset('uploads/product-images/' . $val) }}" height="80px" width="100px" class="mt-1 border" alt="">
										<a href="{{ route('admin.remove.file', ['model' => 'Product', 'id' => $product->id, 'file_name' => $val]) }}" onclick="removeFile(this);" class="position-absolute top-0 end-0 rounded-circle bg-danger text-light px-1"><i class="fa-solid fa-xmark"></i></a>
									</div>
								@endforeach
							@endif
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <div class="d-block step_btn step_btn_1">
            <button type="button" data-step-open="step_2" data-step-button="step_btn_2" data-check-area="step_1" class="btn btn-primary next_btn">Next</button>
        </div>
        <div class="d-none step_btn step_btn_2">
            <a type="button" class="btn m-pr-btn modal__btn_space next_btn" data-step-open="step_1"  data-step-button="step_btn_1">Previous</a>
            <button type="button" class="btn btn-primary next_btn" data-step-open="step_3" data-step-button="step_btn_3" data-check-area="step_2">Next</button>
        </div>
        <div class="d-none step_btn step_btn_3">
            <a type="button" class="btn m-pr-btn modal__btn_space next_btn" data-step-open="step_2" data-step-button="step_btn_2">Previous</a>
            <button type="button" class="btn btn-primary next_btn" data-step-open="step_4" data-step-button="step_btn_4" data-check-area="step_3">Next</button>
        </div>
        <div class="d-none step_btn step_btn_4">
            <a type="button" class="btn m-pr-btn modal__btn_space next_btn" data-step-open="step_3" data-step-button="step_btn_3">Previous</a>
            <button type="button" class="btn btn-primary next_btn" data-step-open="step_5" data-step-button="step_btn_5" data-check-area="step_4">Next</button>
        </div>
        <div class="d-none step_btn step_btn_5">
            <a type="button" class="btn m-pr-btn modal__btn_space next_btn" data-step-open="step_4" data-step-button="step_btn_4">Previous</a>
            <button type="button" class="btn btn-primary next_btn" data-step-open="step_6" data-step-button="step_btn_6" data-check-area="step_5">Next</button>
        </div>
        <div class="d-none step_btn step_btn_6">
            <a type="button" class="btn m-pr-btn modal__btn_space next_btn" data-step-open="step_5" data-step-button="step_btn_5">Previous</a>
            <button type="submit" id="editProductBtn" data-check-area="step_5" class="btn btn-primary">Update</button>
        </div>
    </div>
</form>